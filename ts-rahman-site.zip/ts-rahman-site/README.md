# TS RAHMAN — AI by Shafeeq
Upload a PDF, get AI-generated MCQs with explanations and web-backed "Know More".

## Deploy free (gives you a public link)
1. Create a GitHub repo and upload these files (index.html, api/ai.js, vercel.json). Make the repo public to be open source.
2. Go to vercel.com, sign in with GitHub, "Add New Project", import the repo.
3. In Settings > Environment Variables add `ANTHROPIC_API_KEY` (from console.anthropic.com). Optional: `HOURLY_LIMIT` (default 40 requests per IP per hour), `MODEL`.
4. Deploy. Your link will look like https://your-project.vercel.app

Never put the API key inside index.html. Set a spend limit in the Anthropic console, because anyone with the link can use your quota.
